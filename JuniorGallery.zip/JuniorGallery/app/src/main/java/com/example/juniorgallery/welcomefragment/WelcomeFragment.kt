package com.example.juniorgallery.welcomefragment

import androidx.fragment.app.Fragment

class WelcomeFragment: Fragment() {
}