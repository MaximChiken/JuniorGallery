package com.example.juniorgallery.loginfragment

class LoginPresenter {
}