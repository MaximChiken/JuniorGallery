package com.example.juniorgallery.welcomefragment

class WelcomePresenter {
}