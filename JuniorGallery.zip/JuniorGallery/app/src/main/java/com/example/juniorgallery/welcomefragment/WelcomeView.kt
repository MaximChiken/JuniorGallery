package com.example.juniorgallery.welcomefragment

interface WelcomeView {
}